//
//  YPLibraryVC+CollectionView.swift
//  YPImagePicker
//
//  Created by Sacha DSO on 26/01/2018.
//  Copyright © 2018 Yummypets. All rights reserved.
//

import UIKit

extension YPLibraryVC {
    var isLimitExceeded: Bool { return selection.count >= YPConfig.library.maxNumberOfItems }
    
    func setupCollectionView() {
        v.collectionView.dataSource = self
        v.collectionView.delegate   = self
        v.collectionView.register(YPLibraryViewCell.self, forCellWithReuseIdentifier: "YPLibraryViewCell")
        v.collectionView.layer.cornerRadius = 10
        v.collectionView.clipsToBounds      = true
        
        // Long press on cell to enable multiple selection
//        let longPressGR = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(longPressGR:)))
//        longPressGR.minimumPressDuration = 0.5
//        v.collectionView.addGestureRecognizer(longPressGR)
    }
    
    /// When tapping on the cell with long press, clear all previously selected cells.
    @objc func handleLongPress(longPressGR: UILongPressGestureRecognizer) {
        if multipleSelectionEnabled || isProcessing || YPConfig.library.maxNumberOfItems <= 1 {
            return
        }
        
        if longPressGR.state == .began {
            let point = longPressGR.location(in: v.collectionView)
            guard let indexPath = v.collectionView.indexPathForItem(at: point) else {
                return
            }
            startMultipleSelection(at: IndexPath(item: indexPath.row - 1, section: indexPath.section)) //edit
        }
    }
    
    func startMultipleSelection(at indexPath: IndexPath) {
        currentlySelectedIndex = indexPath.row
        multipleSelectionButtonTapped()
        
        // Update preview.
        changeAsset(mediaManager.fetchResult[indexPath.row])
        
        // Bring preview down and keep selected cell visible.
        panGestureHelper.resetToOriginalState()
        if !panGestureHelper.isImageShown {
            v.collectionView.scrollToItem(at: indexPath, at: .top, animated: true)
        }
        v.refreshImageCurtainAlpha()
    }
    
    // MARK: - Library collection view cell managing
    
    /// Removes cell from selection
    func deselect(indexPath: IndexPath) {
        if let positionIndex = selection.firstIndex(where: {
            $0.assetIdentifier == mediaManager.fetchResult[indexPath.row].localIdentifier
        }) {
            selection.remove(at: positionIndex)

            // Refresh the numbers
            var selectedIndexPaths = [IndexPath]()
            mediaManager.fetchResult.enumerateObjects { [unowned self] (asset, index, _) in
                if self.selection.contains(where: { $0.assetIdentifier == asset.localIdentifier }) {
                    selectedIndexPaths.append(IndexPath(row: index, section: 0))
                }
            }
//            v.collectionView.reloadItems(at: selectedIndexPaths)
            // Replace the current selected image with the previously selected one
            if let previouslySelectedIndexPath = selectedIndexPaths.last {
                v.collectionView.deselectItem(at: indexPath, animated: false)
                v.collectionView.selectItem(at: previouslySelectedIndexPath, animated: false, scrollPosition: [])
                currentlySelectedIndex = previouslySelectedIndexPath.row
                changeAsset(mediaManager.fetchResult[previouslySelectedIndexPath.row])
            }
            v.collectionView.reloadData()
            checkLimit()
        }
    }
    
    /// Adds cell to selection
    func addToSelection(indexPath: IndexPath) {
        if !(delegate?.libraryViewShouldAddToSelection(indexPath: indexPath, numSelections: selection.count) ?? true) {
            return
        }
        
        let asset = mediaManager.fetchResult[indexPath.item]
        selection.append(
            YPLibrarySelection(
                index: indexPath.row,
                assetIdentifier: asset.localIdentifier
            )
        )
        checkLimit()
    }
    
    func isInSelectionPool(indexPath: IndexPath) -> Bool {
        return selection.contains(where: {
            $0.assetIdentifier == mediaManager.fetchResult[indexPath.row].localIdentifier
        })
    }
    
    /// Checks if there can be selected more items. If no - present warning.
    func checkLimit() {
        v.maxNumberWarningView.isHidden = !isLimitExceeded || multipleSelectionEnabled == false
    }
    
    func showPermissionAlert() {
        self.alertYesNo(
            title   : #""WABooK" Would Like to Access the Camera"#,
            message : "메모 등록시 사진첨부를 위해서 카메라 접근을 승인해야 합니다.",
            nobtn   : "Don't Allow",
            yesbtn  : "ok".localized,
            completion: { (ok) in
                if ok {
                    self.gotoAppSettings()
                }
            })
    }
    
    private func checkCameraPermisson( ) {
        self.checkAllowCameraPermission(completion: { (allow) in
            if allow {
                self.openCameraVC()
            }
            else {
                self.showPermissionAlert()
            }
        })
        
    }
    func openCameraVC(){
        DispatchQueue.main.async {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                let vc = self.VC(sbName: "CameraSB", identifier: "CameraVC") as! CameraVC
                self.pushVC(viewController: vc, animated: true)
            }
        }
    }
    
}

extension YPLibraryVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    // + 1 because add camera to to collection
    // - 1 get the current selected image
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mediaManager.fetchResult.count + 1
    }
    
    public func collectionView(_ collectionView: UICollectionView,
                               cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "YPLibraryViewCell",
                                                            for: indexPath) as? YPLibraryViewCell else {
                                                                fatalError("unexpected cell in collection view")
        }
        
//        open camera on first
        if indexPath.row == 0 {
            cell.multipleSelectionIndicator.isHidden    = true
            cell.isSelected                             = false
            cell.imageView.image                        = UIImage(named: "camera_ico-1")
            return cell
        }else{
            let asset = mediaManager.fetchResult[indexPath.item - 1]  //edit
            cell.representedAssetIdentifier                 = asset.localIdentifier
            cell.multipleSelectionIndicator.isHidden        = false
            cell.representedAssetIdentifier                 = asset.localIdentifier
            cell.multipleSelectionIndicator.selectionColor  = YPConfig.colors.multipleItemsSelectedCircleColor
                                                                ?? YPConfig.colors.tintColor
            
            mediaManager.imageManager?.requestImage(for: asset,
                                       targetSize: v.cellSize(),
                                       contentMode: .aspectFill,
                                       options: nil) { image, _ in
                                        // The cell may have been recycled when the time this gets called
                                        // set image only if it's still showing the same asset.
                                        if cell.representedAssetIdentifier == asset.localIdentifier && image != nil {
                                            cell.imageView.image = image
                                        }
            }
            
            let isVideo = (asset.mediaType == .video)
            cell.durationLabel.isHidden = !isVideo
            cell.durationLabel.text = isVideo ? YPHelper.formattedStrigFrom(asset.duration) : ""
    //        cell.multipleSelectionIndicator.isHidden = !multipleSelectionEnabled
//            cell.isSelected = currentlySelectedIndex == indexPath.row //set highlighted image
//            cell.isSelected = false
            cell.index      = indexPath.row
            cell.selection  = selection
            
            // Set correct selection number
            if let index = selection.firstIndex(where: { $0.assetIdentifier == asset.localIdentifier }) {
                let currentSelection = selection[index]
                if currentSelection.index < 0 {
                    selection[index] = YPLibrarySelection(index: indexPath.row - 1, //edit
                                                          cropRect: currentSelection.cropRect,
                                                          scrollViewContentOffset: currentSelection.scrollViewContentOffset,
                                                          scrollViewZoomScale: currentSelection.scrollViewZoomScale,
                                                          assetIdentifier: currentSelection.assetIdentifier)
                }
                cell.multipleSelectionIndicator.set(number: index + 1) // start at 1, not 0
            } else {
                cell.multipleSelectionIndicator.set(number: nil)
            }

            // Prevent weird animation where thumbnail fills cell on first scrolls.
            UIView.performWithoutAnimation {
                cell.layoutIfNeeded()
            }
            return cell
        }
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let cell = collectionView.cellForItem(at: indexPath) as! YPLibraryViewCell
            self.selectionIndexPath = indexPath
            self.checkCameraPermisson()
            cell.isSelected = false
            collectionView.reloadItems(at: [indexPath])
            return
        }else{
            let previouslySelectedIndexPath = IndexPath(row: currentlySelectedIndex, section: 0) //edit
            currentlySelectedIndex = indexPath.row

            changeAsset(mediaManager.fetchResult[indexPath.row - 1]) //edit
            panGestureHelper.resetToOriginalState()
            
            // Only scroll cell to top if preview is hidden.
            if !panGestureHelper.isImageShown {
                collectionView.scrollToItem(at: indexPath, at: .top, animated: true)
            }
            v.refreshImageCurtainAlpha()
                
            if multipleSelectionEnabled {
                let cellIsInTheSelectionPool = isInSelectionPool(indexPath: IndexPath(item: indexPath.row - 1, section: indexPath.section)) //edit
//                let cellIsCurrentlySelected = previouslySelectedIndexPath.row == currentlySelectedIndex
                if cellIsInTheSelectionPool {
                    
                    //double select on image unSelect
//                    if cellIsCurrentlySelected {
//                        deselect(indexPath: IndexPath(item: indexPath.row - 1, section: indexPath.section)) //edit
//                    }
                    deselect(indexPath: IndexPath(item: indexPath.row - 1, section: indexPath.section))
//                    self.currentlySelectedIndex = currentlySelectedIndex + 1 //set highlighted image
                } else if isLimitExceeded == false {
                    addToSelection(indexPath: IndexPath(item: indexPath.row - 1, section: indexPath.section)) //edit
                }
                collectionView.reloadItems(at: [indexPath])
                collectionView.reloadItems(at: [previouslySelectedIndexPath])
                
            } else {
                selection.removeAll()
                addToSelection(indexPath: IndexPath(item: indexPath.row - 1, section: indexPath.section)) //edit
                
                // Force deseletion of previously selected cell.
                // In the case where the previous cell was loaded from iCloud, a new image was fetched
                // which triggered photoLibraryDidChange() and reloadItems() which breaks selection.
                //
                if let previousCell = collectionView.cellForItem(at: previouslySelectedIndexPath) as? YPLibraryViewCell {
                    previousCell.isSelected = false
                }
            }
        }
    }
    
    public func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        return isProcessing == false
    }
    public func collectionView(_ collectionView: UICollectionView, shouldDeselectItemAt indexPath: IndexPath) -> Bool {
        return isProcessing == false
    }
}

extension YPLibraryVC : UICollectionViewDelegateFlowLayout {
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

    //--------------------------------------------------------------------------------

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

    //--------------------------------------------------------------------------------

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: (collectionView.frame.size.width / 3) - 2,height: (collectionView.frame.size.width / 3) - 2)
    }

    //--------------------------------------------------------------------------------

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
    }
}
