//
//  YPImgePicker.h
//  YPImgePicker
//
//  Created by Sacha Durand Saint Omer on 2016/03/26.
//  Copyright © 2016 Yummypets. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for YPImagePicker.
FOUNDATION_EXPORT double YPImagePickerVersionNumber;

//! Project version string for YPImagePicker.
FOUNDATION_EXPORT const unsigned char YPImagePickerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YPImagePicker/PublicHeader.h>


