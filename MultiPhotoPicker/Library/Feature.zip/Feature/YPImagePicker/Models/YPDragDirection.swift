//
//  YPDragDirection.swift
//  YPImagePicker
//
//  Created by Sacha DSO on 26/01/2018.
//  Copyright © 2018 Yummypets. All rights reserved.
//

import Foundation

enum YPDragDirection {
    case scroll
    case stop
    case up
    case down
}
